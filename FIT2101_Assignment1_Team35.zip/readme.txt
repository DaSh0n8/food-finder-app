Individual Contributions:
Ethan Kouris:
-Analysis of Alternatives


Adam Yang
-Project Plan: Summary
-Project Plan: Vision Statement
-Project Plan: Mission Statement
-Project Plan: Team Organization
-Project Plan: Roles and Responsibilities

Khoa Nguyen An
-Risk Register Document

Brandon Lim
-Project Plan: How will tasks be allocated?
-Project Plan: Definition of Done
-Project Plan: Storage and Management of Backlogs

Yuhan Zhou
-Project Plan: Process Models
-Project Plan: Time Management