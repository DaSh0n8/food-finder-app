This submission contains:
- Code for map functionality.
- Sprint 1 retrospective.
- Updated project plan (updated definition of done).

Individual Contributions:
Ethan Kouris:
- Cleaned up user stories.
- Helped design HTML page.

Adam Yang
- Map functionality (all associated user stories in the sprint backlog).
- Edited definition of done in project plan.

Khoa Nguyen An
- CSS for HTML page.
- Began search nearby locations functionality.
- Edited definition of done in project plan.

Brandon Lim
- HTML page.
- Edited definition of done in project plan.

Yuhan Zhou
- Cleaned up user stories.
- Edited definition of done in project plan.